### Hexlet tests and linter status:
[![Actions Status](https://github.com/SergeiNaum/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SergeiNaum/python-project-49/actions)