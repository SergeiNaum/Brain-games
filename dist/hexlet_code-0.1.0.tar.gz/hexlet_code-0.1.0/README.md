### Hexlet tests and linter status:
[![Actions Status](https://github.com/SergeiNaum/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SergeiNaum/python-project-49/actions)

<a href="https://codeclimate.com/github/SergeiNaum/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c62b536dfd604931a711/maintainability" /></a>

[![asciicast](https://asciinema.org/a/11oZ0KaiRUsvJunA34AOBdxFo.svg)](https://asciinema.org/a/11oZ0KaiRUsvJunA34AOBdxFo) 

[![asciicast](https://asciinema.org/a/MbI3TlRIIVCiwP0nho8enrUiK.svg)](https://asciinema.org/a/MbI3TlRIIVCiwP0nho8enrUiK)

[![asciicast](https://asciinema.org/a/d7eLXYy5lzTUNEelFtcNt7HCB.svg)](https://asciinema.org/a/d7eLXYy5lzTUNEelFtcNt7HCB)